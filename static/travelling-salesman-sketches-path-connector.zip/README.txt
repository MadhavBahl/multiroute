A Pen created at CodePen.io. You can find this one at https://codepen.io/jakealbaugh/pen/wqEKeN.

 Given an array of points with an x, y, and preferred next points, draw a path around all without closing the path until the end. Kinda turned into an optimization thing too.